import axios from "axios";

export const mypageApi = {
  getMypage: async () => {
    try {
      const token = localStorage.getItem("accessToken");
      console.log("불러온 토큰:", token);
      const response = await axios.get("/api/mypage", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      console.log("마이페이지 전체 응답:", response);
      if (!response?.data?.data) {
        console.warn("마이페이지 데이터 없음:", response?.data);
      }
      return response?.data?.data || null;
    } catch (error) {
      console.error("마이페이지 정보 요청 실패:", error);
      throw error;
    }
  },
};
